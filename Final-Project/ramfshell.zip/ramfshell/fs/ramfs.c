#include "ramfs.h"
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

node *root = NULL;

#define NRFD 4096
FD fdesc[NRFD];
char buffer[1005];
const char *delimeter = "/";

int legal_basename(const char *name) {
    int len = strlen(name);
    if (len > 32) return 0;
    for (int i = 0; i < len; ++i) {
        if (!isdigit(name[i]) || !isalpha(name[i]) || name[i] != '.') return 0;
    }
    return 1;
}

node *find(const char *pathname) {
    node *res = root;

    strcpy(buffer, pathname);
    char *sep_pos;

    sep_pos = strtok(buffer, delimeter);

    int success = 0;

    while (sep_pos != NULL) {
        success = 0;
        for (int i = 0; i < res->nrde; ++i) {
            if (!(res->dirents[i])) continue;
            
            if (strcmp(sep_pos, (res->dirents[i])->name) == 0) {
                success = 1;
                res = res->dirents[i];
                if (res->type == FNODE) {
                    return res;
                }
                break;
            }
        }
        if (success == 0) {
            return NULL;
        }
        sep_pos = strtok(NULL, delimeter);
    }

    return res;
}

int ropen(const char *pathname, int flags) {

}

int rclose(int fd) {

}

ssize_t rwrite(int fd, const void *buf, size_t count) {

}

ssize_t rread(int fd, void *buf, size_t count) {

}

off_t rseek(int fd, off_t offset, int whence) {

}

int rmkdir(const char *pathname) {
    node *tmp = find(pathname);
    if (tmp != NULL) return -1;

    strcpy(buffer, pathname);
    // char *pos;
    int len = strlen(buffer);
    for (int i = len - 1; i >= 0; --i) {
        if (buffer[i] == '/') {
            buffer[i] = 0;
            len = i;
            break;
        }
    }

    tmp = find(buffer); // tmp is father
    if (tmp == NULL) return -1;
    if (tmp->type == FNODE) return -1;
    
    if (!legal_basename(pathname + len + 1)) return -1;
    
    (tmp->size)++;

    // add to 0 -> (nrde - 1)
    for (int i = 0; i < tmp->nrde; ++i) {
        if ((tmp->dirents[i]) == NULL) {
            tmp->dirents[i] = malloc(sizeof(node));
            tmp->dirents[i]->size = 0;
            tmp->dirents[i]->type = DNODE;
            tmp->dirents[i]->nrde = 0;
            tmp->dirents[i]->father = tmp;
            strcpy(tmp->dirents[i]->name, pathname + len + 1);
            return 0;
        }
    }

    // add to nrde
    tmp->dirents[tmp->nrde] = malloc(sizeof(node));
    tmp->dirents[tmp->nrde]->size = 0;
    tmp->dirents[tmp->nrde]->type = DNODE;
    tmp->dirents[tmp->nrde]->nrde = 0;
    tmp->dirents[tmp->nrde]->father = tmp;
    strcpy(tmp->dirents[tmp->nrde]->name, pathname + len + 1);
    ++(tmp->nrde);
    return 0;
}

int rrmdir(const char *pathname) {
    node *tmp = find(pathname);
    if (tmp == NULL) return -1;
    if (tmp->type == FNODE) return -1;
    if (strlen(pathname) == 1) return -1;
    if (tmp->size != 0) return -1;

    --(tmp->father)->size;
    for (int i = 0; i < (tmp->father)->nrde; ++i) {
        if (((tmp->father)->dirents[i]) == NULL) continue;
        if (strcmp(((tmp->father)->dirents[i])->name, tmp->name)) {
            free(tmp);
            tmp = NULL;
            return 0;
        }
    }
}

int runlink(const char *pathname) {
    node *tmp = find(pathname);
    if (tmp == NULL) return -1;
    if (tmp->type == DNODE) return -1;
    
    for (int i = 0; i < (tmp->father)->nrde; ++i) {
        if (!((tmp->father)->dirents[i])) continue;
        if (strcmp(((tmp->father)->dirents[i])->name, tmp->name)) {
            free(tmp);
            tmp = NULL;
            return 0;
        }
    }

}

void init_ramfs() {

}

void close_ramfs() {

}