#include "sudoku.h"
// 检查某一行是否有效
#include <stdio.h>

#define SIZE 9

// 检查某一行是否有效
int check_row(int grid[SIZE][SIZE], int row) {

}

// 检查某一列是否有效
int check_column(int grid[SIZE][SIZE], int col) {

}

// 检查3x3小方格是否有效
int check_block(int grid[SIZE][SIZE], int start_row, int start_col) {

}
