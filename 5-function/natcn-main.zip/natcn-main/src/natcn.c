#include "natcn.h"

void init(int map[][505], int n, int m) {
    // Write your code here
}

int *get_position(int value, int order) {
    // Do not modify the following line
    int *position = (int *)malloc(2 * sizeof(int));

    // Write your code here
    /*
        Heap memory and pointer, here it is! You don't need to understand it now, just see it as an integer array 'int position[2];'. 
        You can modify the value in this array, the effect will be passed out of this function.
        Let's say:
            position[0] = 1;
            position[1] = 2;
        This stands for a position (1, 2).
        
        @advanced* (you may ignore this part)
            - What would happen if you just use 'int position[2];'?
    */

    // Do not modify the following line
    return position;
}

bool walk(int map[][505], int n, int m, int x, int y, int dx, int dy) {
    // Write your code here
    return false;
}
