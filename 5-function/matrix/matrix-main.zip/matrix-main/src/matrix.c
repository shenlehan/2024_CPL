#include "matrix.h"
void matrix_multiply(int A[][MAX_SIZE],int B[][MAX_SIZE], int C[][MAX_SIZE],  int m, int n, int p){
    //TODO    
}
