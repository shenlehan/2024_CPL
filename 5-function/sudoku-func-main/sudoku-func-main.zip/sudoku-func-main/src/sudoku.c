#include "sudoku.h"
// 检查某一行是否有效
#include <stdio.h>

#define SIZE 9
#define FULL ((1 << 10) - 2)

// 检查某一行是否有效
int check_row(int grid[SIZE][SIZE], int row) {
    int state = 0;
    for (int i = 0; i < SIZE; ++i) {
        state |= (1 << grid[row][i]);
    }
    if (state == FULL)
        return 1;
    return 0;
}

// 检查某一列是否有效
int check_column(int grid[SIZE][SIZE], int col) {
    int state = 0;
    for (int i = 0; i < SIZE; ++i) {
        state |= (1 << grid[i][col]);
    }
    if (state == FULL)
        return 1;
    return 0;
}

// 检查3x3小方格是否有效
int check_block(int grid[SIZE][SIZE], int start_row, int start_col) {
    int state = 0;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            state |= (1 << grid[start_row + i][start_col + j]);
        }
    }
    if (state == FULL)
        return 1;
    return 0;
}
