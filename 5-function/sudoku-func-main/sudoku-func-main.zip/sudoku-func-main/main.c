#include <stdio.h>
#include <sudoku.h>
#define SIZE 9

// 检查整个数独是否满足规则
int is_valid_sudoku(int grid[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        if (!check_row(grid, i) || !check_column(grid, i)) return 0;
    }

    for (int row = 0; row < SIZE; row += 3) {
        for (int col = 0; col < SIZE; col += 3) {
            if (!check_block(grid, row, col)) return 0;
        }
    }

    return 1;
}

int main() {
    int grid[SIZE][SIZE];
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            scanf("%d", &grid[i][j]);
        }
    }

    if (is_valid_sudoku(grid)) {
        printf("YES\n");
    } else {
        printf("NO\n");
    }

    return 0;
}

